//=============================================================================
//	HCL_COMMON.H
//	(C)SEIKO EPSON CORPORATION 2007. All rights reserved.
//=============================================================================

#include "datatype.h"


#ifdef __cplusplus
   extern "C" {
#endif

void	seHclInitRegisters( void );
#ifdef __cplusplus
   }
#endif

