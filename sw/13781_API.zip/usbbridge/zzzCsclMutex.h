// ZZZCSCLMUTEX.H - Prometheus Project Revision History File
// (C)SEIKO EPSON CORPORATION 2009. All rights reserved.

#define	APP_VERSION		"1.00"
#define	APP_REVISION	" $Revision: 15 $"

#define PROMETHEUS_CSCL_LAYER_REVISION (5+APP_REVISION)

// $Header: /13781/API/usbbridge/zzzCsclMutex.h 15    3/12/09 5:45p Paul $
// 
// $Log: /13781/API/usbbridge/zzzCsclMutex.h $
// 
// 15    3/12/09 5:45p Paul
// Remove references to 13772 project.
// 
